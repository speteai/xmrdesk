XMRDesk v1.0.0 - AMD Ryzen Optimized Mining
===========================================

QUICK START:
1. Double-click xmrdesk.exe
2. Select your mining pool
3. Enter your wallet address
4. Click "Start Mining"

FEATURES:
✅ Professional Windows GUI
✅ AMD Ryzen Zen 1-5 Optimizations
✅ CPU Detection & Auto-Configuration
✅ Popular Mining Pools Pre-configured
✅ Real-time Hashrate & Temperature
✅ One-Click Mining Control
✅ Crash-resistant Design

SUPPORTED POOLS:
• SupportXMR.com (Recommended)
• Nanopool.org
• MineXMR.com
• MoneroOcean.stream
• F2Pool

SYSTEM REQUIREMENTS:
• Windows 10/11 (64-bit)
• 4GB+ RAM
• Internet Connection
• AMD Ryzen CPU (Recommended)

DONATION ADDRESS:
48ckezCUYfnj3vDtQRtH1X4ExpvowjRBJj7U36P13KbDPeZ6M3Pjuev3xdCkXPuAuQNomuSDXTBZFTkQRfP33t3gMTjJCpL

PROJECT:
GitHub: https://github.com/speteai/xmrdesk
Version: 1.0.0
Build: Final Windows GUI
