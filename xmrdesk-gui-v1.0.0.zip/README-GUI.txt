XMRDesk GUI v1.0.0 - AMD Ryzen Optimized Mining
================================================

INSTALLATION:
1. Starte xmrdesk-gui.exe direkt (keine .bat Dateien nötig)
2. Das GUI öffnet sich automatisch

FEATURES:
✅ Native Windows GUI Interface
✅ AMD Ryzen Zen 1-5 Optimierungen
✅ CPU-Erkennung und automatische Konfiguration
✅ Pool-Auswahl (SupportXMR, Nanopool, etc.)
✅ Echtzeit Hashrate und Temperatur Anzeige
✅ Ein-Klick Mining Start/Stop

VERWENDUNG:
1. Pool auswählen (Standard: SupportXMR.com)
2. Wallet-Adresse eingeben (oder Standard-Donation verwenden)
3. CPU Threads anpassen (automatisch erkannt)
4. "Mining Starten" klicken

DONATION ADDRESS:
48ckezCUYfnj3vDtQRtH1X4ExpvowjRBJj7U36P13KbDPeZ6M3Pjuev3xdCkXPuAuQNomuSDXTBZFTkQRfP33t3gMTjJCpL

GitHub: github.com/speteai/xmrdesk
